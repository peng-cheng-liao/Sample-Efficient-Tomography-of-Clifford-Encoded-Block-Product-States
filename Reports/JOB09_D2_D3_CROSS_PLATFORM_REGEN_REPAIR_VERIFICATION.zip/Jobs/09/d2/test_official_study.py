#!/usr/bin/env python3
"""Focused regression tests for the official local Job 09 d=2 package."""

from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import fixed_error_scaling_d2 as runner
import freeze_targets
from Optimization.objective import _require_within_scientific_copy_cap


PACKAGE_DIR = Path(__file__).resolve().parent
EXPECTED_PARTITIONS = {
    2: [2], 3: [2, 1], 4: [2, 2], 5: [2, 2, 1],
    6: [2, 2, 2], 7: [2, 2, 2, 1], 8: [2, 2, 2, 2],
    9: [2, 2, 2, 2, 1],
}


class OfficialD2StudyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.manifest = runner.load_task_manifest()
        cls.configs = [runner.config_for_task_id(task_id) for task_id in range(160)]

    def test_task_mapping_and_counts(self) -> None:
        self.assertEqual([item["task_id"] for item in self.manifest["tasks"]], list(range(160)))
        self.assertEqual(
            {(n, sum(config["n"] == n for config in self.configs)) for n in runner.N_VALUES},
            {(n, 20) for n in runner.N_VALUES},
        )
        for config in self.configs:
            self.assertEqual(config["task_id"], (config["n"] - 2) * 20 + config["state_index"])

    def test_official_partitions(self) -> None:
        for config in self.configs:
            self.assertEqual(config["partition"], EXPECTED_PARTITIONS[config["n"]])
            self.assertEqual(max(config["partition"]), 2)

    def test_objective_and_search_are_frozen(self) -> None:
        for config in self.configs:
            objective = config["objective"]
            progressive = config["progressive_search"]
            self.assertEqual(objective["mode"], "fixed_error_min_copies")
            self.assertEqual(objective["error_target"], 0.05)
            self.assertEqual(objective["required_success_count"], 8)
            self.assertEqual(objective["final_tuning_seed_count"], 16)
            self.assertEqual(objective["scientific_copy_cap"], 1_000_000_000)
            self.assertFalse(objective["holdout_enabled"])
            self.assertEqual(progressive["candidate_schedule"], [16, 32, 64, 128, 256])
            self.assertEqual(progressive["max_candidates"], 256)

    def test_seed_and_output_namespaces_are_collision_free(self) -> None:
        seeds: list[int] = []
        outputs: list[str] = []
        for config in self.configs:
            seeds.extend(config["state"]["seed_ledger"].values())
            seeds.append(config["seeds"]["structural_candidate_rng_seed"])
            seeds.extend(config["seeds"]["tuning_seeds"])
            outputs.extend(config["paths"].values())
        self.assertEqual(len(seeds), len(set(seeds)))
        self.assertEqual(len(outputs), len(set(outputs)))

    @staticmethod
    def _reference(config: dict) -> dict:
        frozen = json.loads((PACKAGE_DIR / "canonical_frozen_targets.json").read_text())
        key = f"n{config['n']:02d}/state{config['state_index']:02d}"
        return frozen["targets"][key]

    @staticmethod
    def _with_latent_delta(instance: object, delta: complex) -> object:
        truth = instance.oracle_truth
        blocks = list(truth.latent_block_states)
        matrix = np.asarray(blocks[0].full(), dtype=np.complex128).copy()
        matrix[0, 0] += delta
        blocks[0] = runner._runtime_main_v2.qt.Qobj(matrix, dims=blocks[0].dims)
        return replace(
            instance,
            oracle_truth=replace(truth, latent_block_states=tuple(blocks)),
        )

    def test_fingerprints_and_regeneration_are_stable(self) -> None:
        frozen = json.loads((PACKAGE_DIR / "canonical_frozen_targets.json").read_text())
        fingerprints = [item["canonical_sha256"] for item in frozen["targets"].values()]
        self.assertEqual(len(fingerprints), 160)
        self.assertEqual(len(set(fingerprints)), 160)
        generated, regenerated_frozen, _manifest = freeze_targets.generate_documents(frozen)
        for relative, payload in generated.items():
            self.assertEqual((PACKAGE_DIR / relative).read_bytes(), payload)
        self.assertEqual(regenerated_frozen, frozen)

    def test_reference_aware_tiny_perturbation_and_boundary(self) -> None:
        config = self.configs[0]
        instance = runner.build_instance(config)
        reference = self._reference(config)
        tiny = self._with_latent_delta(instance, 1.0e-15)
        result = freeze_targets.verify_reference_aware_target(
            tiny, reference, expected_n=2, expected_state_index=0
        )
        self.assertEqual(result["canonical_sha256"], reference["canonical_sha256"])
        boundary = self._with_latent_delta(instance, 5.0e-15)
        freeze_targets.verify_reference_aware_target(
            boundary, reference, expected_n=2, expected_state_index=0
        )
        above = self._with_latent_delta(instance, 1.0e-12)
        with self.assertRaisesRegex(RuntimeError, "tolerance"):
            freeze_targets.verify_reference_aware_target(
                above, reference, expected_n=2, expected_state_index=0
            )

    def test_reference_aware_wrong_seed_partition_clifford_and_tableau_fail(self) -> None:
        config = self.configs[0]
        instance = runner.build_instance(config)
        reference = self._reference(config)
        wrong_seed = replace(
            instance,
            seed_ledger=replace(instance.seed_ledger, master_seed=instance.seed_ledger.master_seed + 1),
        )
        with self.assertRaisesRegex(RuntimeError, "identity fields"):
            freeze_targets.verify_reference_aware_target(
                wrong_seed, reference, expected_n=2, expected_state_index=0
            )

        partition_config = self.configs[20]
        partition_instance = runner.build_instance(partition_config)
        partition_reference = self._reference(partition_config)
        wrong_partition_truth = replace(
            partition_instance.oracle_truth,
            hidden_partition=((0,), (1, 2)),
        )
        with self.assertRaisesRegex(RuntimeError, "partition|identity"):
            freeze_targets.verify_reference_aware_target(
                replace(partition_instance, oracle_truth=wrong_partition_truth),
                partition_reference,
                expected_n=3,
                expected_state_index=0,
            )

        truth = instance.oracle_truth
        wrong_gates = replace(truth, encoder_gates=truth.encoder_gates + (("H", 0),))
        with self.assertRaisesRegex(RuntimeError, "Clifford/tableau"):
            freeze_targets.verify_reference_aware_target(
                replace(instance, oracle_truth=wrong_gates),
                reference,
                expected_n=2,
                expected_state_index=0,
            )
        tableau = np.asarray(truth.encoder_tableau, dtype=np.uint8).copy()
        tableau[0, 0] ^= 1
        wrong_tableau = replace(truth, encoder_tableau=tableau)
        with self.assertRaisesRegex(RuntimeError, "Clifford/tableau"):
            freeze_targets.verify_reference_aware_target(
                replace(instance, oracle_truth=wrong_tableau),
                reference,
                expected_n=2,
                expected_state_index=0,
            )

    def test_reference_aware_macroscopic_latent_difference_fails(self) -> None:
        config = self.configs[0]
        instance = runner.build_instance(config)
        with self.assertRaisesRegex(RuntimeError, "tolerance"):
            freeze_targets.verify_reference_aware_target(
                self._with_latent_delta(instance, 1.0e-6),
                self._reference(config),
                expected_n=2,
                expected_state_index=0,
            )

    def test_frozen_file_sha_check_remains_strict(self) -> None:
        config_path = PACKAGE_DIR / "configs" / "n02" / "state00.json"
        reference = self._reference(self.configs[0])
        with tempfile.TemporaryDirectory(prefix="jobs09_d2_sha_") as directory:
            copied = Path(directory) / "state00.json"
            copied.write_bytes(config_path.read_bytes())
            freeze_targets.verify_file_sha256(copied, reference["config_sha256"])
            copied.write_bytes(copied.read_bytes() + b" ")
            with self.assertRaisesRegex(RuntimeError, "SHA-256 mismatch"):
                freeze_targets.verify_file_sha256(copied, reference["config_sha256"])

    def test_general_branch_grouping_and_cap_guard(self) -> None:
        config = self.configs[0]
        optimization, _progressive, _space = runner.build_configs(config, checkpoint_path=None, resume=False)
        derived = runner.derive_candidate(
            runner.smoke_candidate(), n=2, d=2, total_copies=optimization.total_copies,
            optimization_config=optimization, physical_budget=config["preflight"]["smoke_physical_budget"],
        )
        self.assertGreater(dict(derived.fixed_budget_stage_caps)["grouping"], 0)
        self.assertEqual(runner._runtime_main_v2.calibrated_end_to_end_schedule(2, 2, 0.5, 0.2).branch, "generic_d_ge_2")
        with self.assertRaisesRegex(ValueError, "scientific_copy_cap"):
            _require_within_scientific_copy_cap(1_000_000_001, optimization.effective_objective, context="test")

    def test_slurm_contract(self) -> None:
        text = (PACKAGE_DIR / "fixed_error_scaling_d2.sbatch").read_text()
        for value in ("--array=0-159%20", "--mem=16G", "--time=48:00:00", "--cpus-per-task=1"):
            self.assertIn(value, text)
        self.assertNotIn("#SBATCH --signal", text)


if __name__ == "__main__":
    unittest.main()
