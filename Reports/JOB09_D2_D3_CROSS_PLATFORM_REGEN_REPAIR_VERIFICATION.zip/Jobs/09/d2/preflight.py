#!/usr/bin/env python3
"""Comprehensive preflight for the official Job 09 d=2 study."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile

PACKAGE_DIR = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
if str(PACKAGE_DIR) not in sys.path:
    sys.path.insert(0, str(PACKAGE_DIR))

import fixed_error_scaling_d2 as runner  # noqa: E402
import freeze_targets  # noqa: E402
from Optimization.checkpoint import CheckpointStore  # noqa: E402
from Optimization.objective import _require_within_scientific_copy_cap  # noqa: E402
from Optimization.parameterization import candidate_to_end_to_end_config  # noqa: E402
from runtime_support import validate_runtime_provenance  # noqa: E402


STUDY_D = 2
EXPECTED_PARTITIONS = {
    2: [2], 3: [2, 1], 4: [2, 2], 5: [2, 2, 1],
    6: [2, 2, 2], 7: [2, 2, 2, 1], 8: [2, 2, 2, 2],
    9: [2, 2, 2, 2, 1],
}


def validate_sbatch() -> None:
    path = PACKAGE_DIR / "fixed_error_scaling_d2.sbatch"
    completed = subprocess.run(("bash", "-n", str(path)), capture_output=True, text=True)
    if completed.returncode:
        raise RuntimeError("Slurm syntax failed: " + completed.stderr)
    text = path.read_text(encoding="utf-8")
    required = (
        "#SBATCH --account=qzhuang_922", "#SBATCH --nodes=1",
        "#SBATCH --ntasks=1", "#SBATCH --cpus-per-task=1",
        "#SBATCH --mem=16G", "#SBATCH --time=48:00:00",
        "#SBATCH --partition=epyc-64", "#SBATCH --array=0-159%20",
        "#SBATCH --job-name=cebp09_d2_scaling", "#SBATCH --requeue",
        '--task-id "${TASK_ID}"',
    )
    missing = [item for item in required if item not in text]
    if missing or "#SBATCH --signal" in text or "TERM@120" in text:
        raise RuntimeError(f"Slurm design mismatch: missing={missing!r}")


def reference_fingerprints() -> set[str]:
    parent = PACKAGE_DIR.parent
    manifests = [
        parent / "canonical_frozen_targets.json",
        parent / "test1" / "canonical_frozen_targets.json",
        parent / "test2" / "canonical_frozen_targets.json",
        parent / "d3" / "canonical_frozen_targets.json",
    ]
    values: set[str] = set()
    for path in manifests:
        if not path.is_file():
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        values.update(str(item["canonical_sha256"]) for item in payload["targets"].values())
    return values


def validate_checkpoint_isolation(configs: list[dict]) -> None:
    keys = [str(config["checkpoint_key"]) for config in configs]
    if len(keys) != len(set(keys)) or any("official-d2-v1" not in key for key in keys):
        raise RuntimeError("Checkpoint identities are not unique d=2 identities.")
    with tempfile.TemporaryDirectory(prefix="jobs09_d2_checkpoint_") as directory:
        path = Path(directory) / "checkpoint.json"
        CheckpointStore(
            str(path), expected_metadata={"checkpoint_key": keys[0]}, every_n_evaluations=1
        ).save({}, {}, status="running")
        wrong_keys = (
            keys[1], keys[20], keys[-1],
            keys[0].replace(keys[0].split("-")[6], "0" * 16, 1),
            keys[0].replace("official-d2", "official-d3"),
            keys[0].replace("official-d2", "official-d1"),
        )
        for wrong_key in wrong_keys:
            try:
                CheckpointStore(
                    str(path), expected_metadata={"checkpoint_key": wrong_key},
                    every_n_evaluations=1,
                ).load()
            except ValueError as error:
                if "Incompatible checkpoint metadata" not in str(error):
                    raise
            else:
                raise RuntimeError("An incompatible checkpoint identity was accepted.")


def validate_general_branch(config: dict) -> None:
    optimization, progressive, _space = runner.build_configs(
        config, checkpoint_path=None, resume=False
    )
    progressive.validate_for(optimization)
    budget = int(config["preflight"]["smoke_physical_budget"])
    derived = runner.derive_candidate(
        runner.smoke_candidate(), n=int(config["n"]), d=STUDY_D,
        total_copies=optimization.total_copies, optimization_config=optimization,
        physical_budget=budget,
    )
    end_to_end = candidate_to_end_to_end_config(
        derived, d=STUDY_D, learner_seed=int(config["seeds"]["tuning_seeds"][0]),
        total_copies=budget, optimization_config=optimization,
    )
    if end_to_end.grouping_override is None or end_to_end.grouping_override.ell_grp != STUDY_D:
        raise RuntimeError("The d=2 candidate did not resolve ell_grp=d.")
    if dict(derived.fixed_budget_stage_caps).get("grouping", 0) <= 0:
        raise RuntimeError("The five-stage d=2 budget did not allocate grouping.")
    if runner._runtime_main_v2.calibrated_end_to_end_schedule(2, STUDY_D, 0.5, 0.2).branch != "generic_d_ge_2":
        raise RuntimeError("d=2 resolved the d=1 specialized branch.")
    try:
        _require_within_scientific_copy_cap(
            1_000_000_001, optimization.effective_objective, context="preflight"
        )
    except ValueError as error:
        if "scientific_copy_cap" not in str(error):
            raise
    else:
        raise RuntimeError("The scientific cap guard accepted an over-cap E2E budget.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--isolated", action="store_true")
    parser.add_argument("--skip-smoke", action="store_true")
    args = parser.parse_args(argv)
    validate_runtime_provenance()
    validate_sbatch()
    manifest = runner.load_task_manifest()
    if [int(item["task_id"]) for item in manifest["tasks"]] != list(range(160)):
        raise RuntimeError("d=2 task IDs are not exactly 0..159.")
    frozen = json.loads(runner.CANONICAL_TARGETS_PATH.read_text(encoding="utf-8"))
    if frozen.get("target_count") != 160 or len(frozen.get("targets", {})) != 160:
        raise RuntimeError("d=2 frozen-target count is not 160.")
    external_fingerprints = set() if args.isolated else reference_fingerprints()
    configs: list[dict] = []
    fingerprints: set[str] = set()
    seeds: set[int] = set()
    result_paths: set[str] = set()
    checkpoint_paths: set[str] = set()
    log_paths: set[str] = set()
    counts = {n: 0 for n in runner.N_VALUES}
    for task_id in range(160):
        config = runner.config_for_task_id(task_id)
        configs.append(config)
        n = int(config["n"])
        counts[n] += 1
        if config["partition"] != EXPECTED_PARTITIONS[n] or max(config["partition"]) != STUDY_D:
            raise RuntimeError(f"Task {task_id} has the wrong official d=2 partition.")
        objective = config["objective"]
        progressive = config["progressive_search"]
        if (
            objective["mode"] != "fixed_error_min_copies"
            or objective["error_target"] != 0.05
            or objective["success_probability_threshold"] != 0.5
            or objective["required_success_count"] != 8
            or objective["final_tuning_seed_count"] != 16
            or objective["scientific_copy_cap"] != 1_000_000_000
            or objective["holdout_enabled"] is not False
            or progressive["candidate_schedule"] != [16, 32, 64, 128, 256]
            or progressive["max_candidates"] != 256
        ):
            raise RuntimeError(f"Task {task_id} changes the official objective.")
        role_seeds = [
            *[int(value) for value in config["state"]["seed_ledger"].values()],
            int(config["seeds"]["structural_candidate_rng_seed"]),
            *[int(value) for value in config["seeds"]["tuning_seeds"]],
        ]
        if len(role_seeds) != len(set(role_seeds)) or seeds.intersection(role_seeds):
            raise RuntimeError(f"Seed collision at task {task_id}.")
        seeds.update(role_seeds)
        instance = runner.build_instance(config)
        verification = runner.target_fingerprint_verification(config, instance)
        fingerprint = str(verification["canonical_actual_sha256"])
        if fingerprint in fingerprints or fingerprint in external_fingerprints:
            raise RuntimeError(f"Target fingerprint overlap at task {task_id}.")
        fingerprints.add(fingerprint)
        item = manifest["tasks"][task_id]
        result_paths.add(str(item["result_path"]))
        checkpoint_paths.add(str(item["checkpoint_path"]))
        log_paths.add(str(item["log_path_template"]))
    if counts != {n: 20 for n in runner.N_VALUES}:
        raise RuntimeError(f"d=2 target counts are wrong: {counts!r}")
    if any(len(values) != 160 for values in (result_paths, checkpoint_paths, log_paths)):
        raise RuntimeError("d=2 mutable output paths are not unique.")
    generated, _targets, _tasks = freeze_targets.generate_documents(frozen)
    mismatches = [
        relative for relative, payload in generated.items()
        if not (PACKAGE_DIR / relative).is_file() or (PACKAGE_DIR / relative).read_bytes() != payload
    ]
    if mismatches:
        raise RuntimeError(
            f"d=2 reference-aware deterministic regeneration changed: {mismatches[:5]!r}"
        )
    validate_checkpoint_isolation(configs)
    validate_general_branch(configs[0])
    smoke = None if args.skip_smoke else runner.run_smoke(configs[0])
    if smoke is not None and smoke["execution_branch"] != "generic_d_ge_2":
        raise RuntimeError("d=2 numerical smoke did not use the general branch.")
    for n in runner.N_VALUES:
        print(f"n={n:02d} targets={counts[n]} PASS")
    print(
        "preflight=PASS targets=160 failed=0 "
        f"smoke={'SKIPPED' if smoke is None else 'PASS'}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
