#!/usr/bin/env python3
"""Deterministically freeze all 160 official Job 09 d=2 target states."""

from __future__ import annotations

from dataclasses import asdict
import base64
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Mapping

PACKAGE_DIR = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
if str(PACKAGE_DIR) not in sys.path:
    sys.path.insert(0, str(PACKAGE_DIR))

from runtime_support import activate_packaged_runtime  # noqa: E402

activate_packaged_runtime()

import numpy as np  # noqa: E402
from main_v2 import random_cebp_state  # noqa: E402


TARGETS_PER_N = 20
STUDY_D = 2
N_VALUES = tuple(range(2, 10))
TARGET_COUNT = len(N_VALUES) * TARGETS_PER_N
CANONICAL_TARGET_QUANTIZATION_BITS = 48
CANONICAL_TARGET_LATENT_ABSOLUTE_TOLERANCE = 5.0e-15


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def legacy_fingerprint(instance: Any) -> str:
    digest = hashlib.sha256(b"jobs09-frozen-target-v1\0")
    truth = instance.oracle_truth
    digest.update(canonical_json([list(block) for block in truth.hidden_partition]).encode())
    digest.update(np.asarray(truth.encoder_tableau, dtype=np.uint8).tobytes(order="C"))
    digest.update(canonical_json(list(truth.encoder_gates)).encode())
    for block in truth.latent_block_states:
        matrix = np.ascontiguousarray(block.full(), dtype="<c16")
        digest.update(canonical_json(list(matrix.shape)).encode())
        digest.update(matrix.tobytes(order="C"))
    digest.update(canonical_json(asdict(instance.seed_ledger)).encode())
    return digest.hexdigest()


def _canonical_fingerprint_with_matrices(
    instance: Any, matrices: list[np.ndarray]
) -> str:
    digest = hashlib.sha256(b"jobs09-canonical-target-v1\0")
    truth = instance.oracle_truth
    digest.update(canonical_json([list(block) for block in truth.hidden_partition]).encode())
    digest.update(np.asarray(truth.encoder_tableau, dtype=np.uint8).tobytes(order="C"))
    digest.update(canonical_json(list(truth.encoder_gates)).encode())
    digest.update(canonical_json({"binary_quantization_bits": CANONICAL_TARGET_QUANTIZATION_BITS}).encode())
    scale = float(2**CANONICAL_TARGET_QUANTIZATION_BITS)
    for matrix in matrices:
        real = np.ascontiguousarray(np.rint(matrix.real * scale), dtype="<i8")
        imag = np.ascontiguousarray(np.rint(matrix.imag * scale), dtype="<i8")
        digest.update(canonical_json(list(matrix.shape)).encode())
        digest.update(real.tobytes(order="C"))
        digest.update(imag.tobytes(order="C"))
    digest.update(canonical_json(asdict(instance.seed_ledger)).encode())
    return digest.hexdigest()


def canonical_fingerprint(instance: Any) -> str:
    matrices = [
        np.ascontiguousarray(block.full(), dtype="<c16")
        for block in instance.oracle_truth.latent_block_states
    ]
    return _canonical_fingerprint_with_matrices(instance, matrices)


def verify_reference_aware_target(
    instance: Any,
    reference: Mapping[str, Any],
    *,
    expected_n: int,
    expected_state_index: int,
    tolerance: float = CANONICAL_TARGET_LATENT_ABSOLUTE_TOLERANCE,
) -> dict[str, Any]:
    """Require exact discrete identity and tolerant latent-state equivalence."""

    truth = instance.oracle_truth
    actual_seed_ledger = {
        name: int(value) for name, value in asdict(instance.seed_ledger).items()
    }
    expected_discrete = {
        "d": STUDY_D,
        "n": int(expected_n),
        "state_index": int(expected_state_index),
        "block_sizes": list(official_partition(expected_n)),
        "state_seed": int(instance.seed_ledger.master_seed),
        "seed_ledger": actual_seed_ledger,
    }
    discrete_mismatches = [
        name
        for name, value in expected_discrete.items()
        if reference.get(name) != value
    ]
    actual_block_sizes = [len(block) for block in truth.hidden_partition]
    if actual_block_sizes != expected_discrete["block_sizes"]:
        discrete_mismatches.append("generated_hidden_partition")
    expected_generation_metadata = {
        "encoder_sampling": "nonuniform_h_s_cnot_random_walk",
        "encoder_steps": 5 * int(expected_n),
        "latent_state_source": "hilbert_schmidt_mixed",
    }
    for name, value in expected_generation_metadata.items():
        if getattr(truth, name) != value:
            discrete_mismatches.append(name)
    if discrete_mismatches:
        raise RuntimeError(
            "Cross-platform regeneration changed exact target identity fields: "
            + ", ".join(sorted(set(discrete_mismatches)))
        )

    latent_references = reference.get("latent_blocks", ())
    if (
        len(truth.latent_block_states) != int(reference.get("latent_block_count", -1))
        or len(latent_references) != len(truth.latent_block_states)
    ):
        raise RuntimeError("Cross-platform regeneration changed latent block count.")

    reference_matrices: list[np.ndarray] = []
    block_metrics: list[dict[str, Any]] = []
    for block_index, (block, latent) in enumerate(
        zip(truth.latent_block_states, latent_references, strict=True)
    ):
        actual = np.ascontiguousarray(block.full(), dtype="<c16")
        shape = tuple(int(item) for item in latent["shape"])
        raw = base64.b64decode(latent["reference_c16le_base64"], validate=True)
        expected_nbytes = int(np.prod(shape)) * np.dtype("<c16").itemsize
        if len(raw) != expected_nbytes:
            raise RuntimeError(f"Latent reference block {block_index} has invalid length.")
        expected = np.frombuffer(raw, dtype="<c16").reshape(shape)
        if actual.shape != shape:
            raise RuntimeError(f"Latent reference block {block_index} changed shape.")
        maximum_difference = float(np.max(np.abs(actual - expected)))
        if not np.isfinite(maximum_difference) or maximum_difference > float(tolerance):
            raise RuntimeError(
                f"Latent reference block {block_index} differs by {maximum_difference:.17g}; "
                f"tolerance is {float(tolerance):.1e}."
            )
        reference_matrices.append(expected)
        block_metrics.append({
            "block_index": block_index,
            "shape": list(shape),
            "max_abs_difference": maximum_difference,
            "frobenius_difference": float(np.linalg.norm(actual - expected)),
        })

    canonical = _canonical_fingerprint_with_matrices(instance, reference_matrices)
    if canonical != str(reference.get("canonical_sha256")):
        raise RuntimeError(
            "Cross-platform regeneration changed the Clifford/tableau, partition, "
            "seed ledger, or canonical target identity."
        )
    return {
        "canonical_sha256": canonical,
        "tolerance": float(tolerance),
        "blocks": block_metrics,
    }


def verify_file_sha256(path: Path, expected_sha256: str) -> None:
    actual = file_sha256(path)
    if actual != str(expected_sha256):
        raise RuntimeError(
            f"Frozen file SHA-256 mismatch for {path}: expected {expected_sha256}, got {actual}."
        )


def official_partition(n: int) -> tuple[int, ...]:
    return (2,) * (n // 2) + ((1,) if n % 2 else ())


def latent_reference(instance: Any) -> dict[str, Any]:
    blocks = [np.ascontiguousarray(block.full(), dtype="<c16") for block in instance.oracle_truth.latent_block_states]
    if not blocks:
        raise RuntimeError("Expected at least one latent block.")
    return {
        "latent_block_count": len(blocks),
        "latent_blocks": [
            {
                "shape": list(block.shape),
                "reference_c16le_base64": base64.b64encode(
                    block.tobytes(order="C")
                ).decode("ascii"),
            }
            for block in blocks
        ],
    }


def build_config(
    spec: dict[str, Any],
    n: int,
    state_index: int,
    task_id: int,
    instance: Any,
    canonical: str,
) -> dict[str, Any]:
    namespace = spec["seed_namespace"]
    state_seed = int(namespace["state_seed_base"]) + task_id
    search_seed = int(namespace["search_seed_base"]) + task_id
    tuning_base = int(namespace["tuning_seed_base"]) + 16 * task_id
    fingerprint = legacy_fingerprint(instance)
    return {
        "schema_version": 3,
        "package_revision": spec["package_revision"],
        "job": spec["job"],
        "task_id": task_id,
        "n": n,
        "d": STUDY_D,
        "state_index": state_index,
        "partition": list(official_partition(n)),
        "state": {
            "generator": spec["state_generation"]["generator"],
            "state_seed": state_seed,
            "seed_ledger": {name: int(value) for name, value in asdict(instance.seed_ledger).items()},
            "pure": spec["state_generation"]["pure"],
            "block_ensemble": spec["state_generation"]["block_ensemble"],
            "clifford_steps": spec["state_generation"]["clifford_steps_per_qubit"] * n,
            "clifford_sampler": spec["state_generation"]["clifford_sampler"],
            "oracle_backend": spec["state_generation"]["oracle_backend"],
            "frozen_state_sha256": fingerprint,
        },
        "seeds": {
            "structural_candidate_rng_seed": search_seed,
            "tuning_seeds": [tuning_base + index for index in range(16)],
        },
        "objective": spec["objective"],
        "adaptive_budget_search": spec["adaptive_budget_search"],
        "progressive_search": spec["progressive_search"],
        "runtime": spec["runtime"],
        "search_space": spec["search_space"],
        "preflight": spec["preflight"],
        "checkpoint_key": (
            f"job09-official-d2-v1-n{n:02d}-state{state_index:02d}-{canonical[:16]}-"
            "fixed-error-e0p05-p0p50-r8of16-cap1e9-sched16-32-64-128-256"
        ),
        "paths": {
            "checkpoint": f"checkpoints/n{n:02d}/state{state_index:02d}_checkpoint.json",
            "result": f"results/n{n:02d}/state{state_index:02d}_result.json",
            "status": f"results/n{n:02d}/state{state_index:02d}_status.json",
        },
    }


def generate_documents(
    reference_manifest: Mapping[str, Any] | None = None,
) -> tuple[dict[str, bytes], dict[str, Any], dict[str, Any]]:
    spec = json.loads((PACKAGE_DIR / "official_study_spec.json").read_text(encoding="utf-8"))
    if reference_manifest is not None and (
        reference_manifest.get("schema_version") != 3
        or reference_manifest.get("algorithm") != "jobs09-canonical-target-v1"
        or reference_manifest.get("binary_quantization_bits")
        != CANONICAL_TARGET_QUANTIZATION_BITS
        or float(reference_manifest.get("latent_reference_absolute_tolerance", -1.0))
        != CANONICAL_TARGET_LATENT_ABSOLUTE_TOLERANCE
        or int(reference_manifest.get("target_count", -1)) != TARGET_COUNT
    ):
        raise RuntimeError("Unsupported authoritative frozen-target reference manifest.")
    generated: dict[str, bytes] = {}
    targets: dict[str, Any] = {}
    tasks: list[dict[str, Any]] = []
    all_seeds: set[int] = set()
    fingerprints: set[str] = set()
    for n in N_VALUES:
        for state_index in range(TARGETS_PER_N):
            task_id = (n - N_VALUES[0]) * TARGETS_PER_N + state_index
            state_seed = int(spec["seed_namespace"]["state_seed_base"]) + task_id
            instance = random_cebp_state(
                n=n,
                d=STUDY_D,
                block_sizes=official_partition(n),
                pure=False,
                clifford_steps=5 * n,
                seed=state_seed,
                oracle_backend="structured",
                max_dense_debug_qubits=int(spec["runtime"]["max_dense_debug_qubits"]),
            )
            target_key = f"n{n:02d}/state{state_index:02d}"
            reference = (
                reference_manifest["targets"][target_key]
                if reference_manifest is not None
                else None
            )
            if reference is None:
                canonical = canonical_fingerprint(instance)
            else:
                canonical = verify_reference_aware_target(
                    instance,
                    reference,
                    expected_n=n,
                    expected_state_index=state_index,
                )["canonical_sha256"]
            config = build_config(spec, n, state_index, task_id, instance, canonical)
            if reference is not None:
                config["state"]["frozen_state_sha256"] = str(
                    reference["legacy_raw_sha256"]
                )
            relative_config = f"configs/n{n:02d}/state{state_index:02d}.json"
            config_payload = json_bytes(config)
            config_hash = sha256_bytes(config_payload)
            generated[relative_config] = config_payload
            if canonical in fingerprints:
                raise RuntimeError(f"Duplicate canonical target fingerprint at task {task_id}.")
            fingerprints.add(canonical)
            seed_values = [
                *[int(value) for value in asdict(instance.seed_ledger).values()],
                int(config["seeds"]["structural_candidate_rng_seed"]),
                *[int(value) for value in config["seeds"]["tuning_seeds"]],
            ]
            for seed in seed_values:
                if seed in all_seeds:
                    raise RuntimeError(f"Seed collision at task {task_id}: {seed}.")
                all_seeds.add(seed)
            latent = (
                {
                    "latent_block_count": int(reference["latent_block_count"]),
                    "latent_blocks": reference["latent_blocks"],
                }
                if reference is not None
                else latent_reference(instance)
            )
            targets[target_key] = {
                "task_id": task_id,
                "n": n,
                "d": STUDY_D,
                "state_index": state_index,
                "block_sizes": list(official_partition(n)),
                "state_seed": state_seed,
                "seed_ledger": config["state"]["seed_ledger"],
                "legacy_raw_sha256": config["state"]["frozen_state_sha256"],
                "canonical_sha256": canonical,
                "config_path": relative_config,
                "config_sha256": config_hash,
                **latent,
            }
            tasks.append({
                "task_id": task_id,
                "n": n,
                "d": STUDY_D,
                "state_index": state_index,
                "block_sizes": list(official_partition(n)),
                "config_path": relative_config,
                "result_path": config["paths"]["result"],
                "checkpoint_path": config["paths"]["checkpoint"],
                "status_path": config["paths"]["status"],
                "log_path_template": f"logs/n{n:02d}/state{state_index:02d}_%A_%a.{{out,err}}",
                "state_seed": state_seed,
                "partition_seed": int(config["state"]["seed_ledger"]["partition_seed"]),
                "latent_state_seed": int(config["state"]["seed_ledger"]["latent_state_seed"]),
                "clifford_seed": int(config["state"]["seed_ledger"]["clifford_seed"]),
                "search_seed": int(config["seeds"]["structural_candidate_rng_seed"]),
                "tuning_seeds": config["seeds"]["tuning_seeds"],
                "canonical_target_fingerprint": canonical,
                "config_sha256": config_hash,
            })
    frozen = {
        "schema_version": 3,
        "algorithm": "jobs09-canonical-target-v1",
        "study_revision": spec["package_revision"],
        "seed_namespace": spec["seed_namespace"],
        "binary_quantization_bits": CANONICAL_TARGET_QUANTIZATION_BITS,
        "latent_reference_absolute_tolerance": CANONICAL_TARGET_LATENT_ABSOLUTE_TOLERANCE,
        "target_count": TARGET_COUNT,
        "targets_per_n": TARGETS_PER_N,
        "targets": targets,
    }
    manifest = {
        "schema_version": 1,
        "study_revision": spec["package_revision"],
        "mapping": "task_id=(n-2)*20+state_index",
        "task_count": TARGET_COUNT,
        "tasks": tasks,
    }
    generated["canonical_frozen_targets.json"] = json_bytes(frozen)
    generated["task_manifest.json"] = json_bytes(manifest)
    return generated, frozen, manifest


def main(argv: list[str] | None = None) -> int:
    check = argv is not None and "--check" in argv
    reference_manifest = None
    if check:
        reference_manifest = json.loads(
            (PACKAGE_DIR / "canonical_frozen_targets.json").read_text(encoding="utf-8")
        )
    generated, frozen, manifest = generate_documents(reference_manifest)
    mismatches: list[str] = []
    for relative, payload in sorted(generated.items()):
        destination = PACKAGE_DIR / relative
        if check:
            if not destination.is_file() or destination.read_bytes() != payload:
                mismatches.append(relative)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(payload)
    if mismatches:
        raise RuntimeError(f"Deterministic freeze mismatch: {mismatches!r}")
    print(
        f"freeze={'PASS' if check else 'WRITTEN'} targets={frozen['target_count']} "
        f"tasks={manifest['task_count']} fingerprints=unique seeds=collision_free"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
